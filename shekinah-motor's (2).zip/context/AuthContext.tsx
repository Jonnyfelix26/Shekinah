
import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { auth } from '../lib/firebase';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  signInWithPopup, 
  signInWithPhoneNumber, 
  signOut, 
  GoogleAuthProvider, 
  RecaptchaVerifier, 
  User, 
  ConfirmationResult 
} from 'firebase/auth';

type UserRole = 'admin' | 'client';

interface AuthState {
  isAuthenticated: boolean;
  role: UserRole;
  user: User | null;
  loading: boolean;
}

interface AuthContextType {
  auth: AuthState;
  login: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  loginWithPhone: (phoneNumber: string, appVerifier: RecaptchaVerifier) => Promise<ConfirmationResult>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  auth: { isAuthenticated: false, role: 'client', user: null, loading: true },
  login: async () => {},
  loginWithGoogle: async () => {},
  loginWithPhone: async () => Promise.reject("Not implemented"),
  logout: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    role: 'client',
    user: null,
    loading: true
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setAuthState({ isAuthenticated: true, role: 'admin', user, loading: false });
      } else {
        setAuthState({ isAuthenticated: false, role: 'client', user: null, loading: false });
      }
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, password: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error) {
      console.error("Error al iniciar sesión:", error);
      throw error;
    }
  };

  const loginWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Error con Google Auth:", error);
      throw error;
    }
  };

  const loginWithPhone = async (phoneNumber: string, appVerifier: RecaptchaVerifier): Promise<ConfirmationResult> => {
    try {
      return await signInWithPhoneNumber(auth, phoneNumber, appVerifier);
    } catch (error) {
      console.error("Error con Phone Auth:", error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Error al cerrar sesión", error);
    }
  };

  return (
    <AuthContext.Provider value={{ auth: authState, login, loginWithGoogle, loginWithPhone, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
