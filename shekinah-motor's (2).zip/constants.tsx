
import React from 'react';
import type { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 1,
    category: 'Cascos y fundas',
    name: 'Casco AGV K3 SV',
    price: 850.00,
    stock: 5,
    description: ['Certificación ECE 22.05', 'Visor solar integrado', 'Sistema de ventilación IVS', 'Interior Dry-Comfort desmontable'],
    imageBg: 'bg-white',
    color: 'blue-600',
    badge: 'PREMIUM',
    icon: (
      <svg viewBox="0 0 200 200" className="w-full h-40">
        <path d="M100,20 C60,20 30,50 30,90 L30,150 Q30,180 60,180 L140,180 Q170,180 170,150 L170,90 C170,50 140,20 100,20 Z" fill="#e2e8f0" stroke="#1e293b" strokeWidth="4" />
        <path d="M30,90 Q100,60 170,90 L170,130 Q100,100 30,130 Z" fill="#3b82f6" opacity="0.9" />
        <rect x="80" y="140" width="40" height="30" rx="5" fill="#0f172a" />
      </svg>
    ),
  },
  {
    id: 2,
    category: 'Protección personal',
    name: 'Chaqueta Alpinestars T-GP',
    price: 650.00,
    stock: 8,
    description: ['Protecciones Nucleon Flex', 'Refuerzos de poliéster 600D', 'Membrana impermeable', 'Forro térmico desmontable'],
    imageBg: 'bg-white',
    color: 'red-600',
    icon: (
      <svg viewBox="0 0 200 200" className="w-full h-40">
        <path d="M60,40 L140,40 L160,80 L160,180 L140,180 L140,100 L60,100 L60,180 L40,180 L40,80 Z" fill="#ef4444" stroke="#7f1d1d" strokeWidth="4" />
        <rect x="95" y="40" width="10" height="140" fill="#7f1d1d" />
        <path d="M40,80 L80,60" stroke="#fff" strokeWidth="2" />
        <path d="M160,80 L120,60" stroke="#fff" strokeWidth="2" />
      </svg>
    ),
  },
  {
    id: 3,
    category: 'Parrillas y sliders',
    name: 'Slider de Motor Universal',
    price: 120.00,
    stock: 20,
    description: ['Aluminio CNC anodizado', 'Protección contra caídas', 'Fácil instalación', 'Disponible en varios colores'],
    imageBg: 'bg-white',
    color: 'gray-600',
    icon: (
      <svg viewBox="0 0 200 200" className="w-full h-40">
        <circle cx="60" cy="100" r="30" fill="#334155" />
        <rect x="60" y="85" width="100" height="30" fill="#94a3b8" />
        <circle cx="160" cy="100" r="10" fill="#334155" />
      </svg>
    ),
  },
  {
    id: 4,
    category: 'Accesorios generales',
    name: 'Soporte Celular Aluminio',
    price: 45.00,
    stock: 15,
    description: ['Rotación 360 grados', 'Agarre antideslizante', 'Compatible con todos los manillares', 'Puerto de carga USB opcional'],
    imageBg: 'bg-white',
    color: 'green-600',
    badge: 'OFERTA',
    icon: (
      <svg viewBox="0 0 200 200" className="w-full h-40">
        <rect x="80" y="50" width="40" height="80" rx="5" fill="#0f172a" />
        <rect x="85" y="55" width="30" height="70" fill="#3b82f6" />
        <rect x="70" y="130" width="60" height="10" fill="#64748b" />
        <rect x="95" y="140" width="10" height="30" fill="#64748b" />
      </svg>
    ),
  },
];
