
import React, { useState } from 'react';
import { useProducts } from '../context/ProductContext';
import { useAuth } from '../context/AuthContext';
import ProductCard from './ProductCard';
import { PlusIcon } from './Icons';
import AdminProductModal from './AdminProductModal';
import type { Product } from '../types';

const ShopSection: React.FC = () => {
  const { products, loading } = useProducts();
  const { auth } = useAuth();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('Todos');

  // Categorías de Moto
  const categories = [
    'Todos', 
    'Accesorios generales',
    'Accesorios de lujo',
    'Protección personal',
    'Parrillas y sliders',
    'Cascos y fundas',
    'Stickers resinados'
  ];

  // Filter logic
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          product.description.some(d => d.toLowerCase().includes(searchTerm.toLowerCase()));
    
    // Strict category matching
    const matchesCategory = activeCategory === 'Todos' || product.category === activeCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <section id="tienda" className="mb-12 relative min-h-[600px] pt-8">
      {/* Admin Floating Add Button (Bottom Right) */}
      {auth.isAuthenticated && (
        <div className="fixed bottom-8 right-8 z-40">
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white w-16 h-16 rounded-full shadow-2xl flex items-center justify-center transition-transform hover:scale-110 border-4 border-white animate-bounce-subtle"
            title="Agregar Producto"
          >
            <PlusIcon className="w-8 h-8" />
          </button>
        </div>
      )}

      <AdminProductModal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} />

      {/* Controls Header */}
      <div className="mb-10 bg-[#1f2937] p-6 rounded-xl shadow-lg border border-gray-700">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
           
           {/* Search Bar */}
           <div className="w-full md:w-1/3 relative">
              <input 
                type="text" 
                placeholder="Buscar producto..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-[#111827] border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all text-white placeholder-gray-500"
              />
              <svg className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
           </div>
           
           {/* Category Filters (Desktop) */}
           <div className="hidden md:flex flex-wrap gap-2 justify-end w-full md:w-2/3">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-all ${
                    activeCategory === cat 
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30' 
                      : 'bg-[#111827] text-gray-400 hover:bg-gray-700 hover:text-white border border-gray-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
           </div>

           {/* Category Filter (Mobile) */}
           <div className="md:hidden w-full">
             <select 
               value={activeCategory}
               onChange={(e) => setActiveCategory(e.target.value)}
               className="w-full px-4 py-3 bg-[#111827] border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-blue-500 outline-none"
             >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
             </select>
           </div>
        </div>
      </div>

      {/* Loading State */}
      {loading ? (
         <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1,2,3].map(i => (
               <div key={i} className="bg-white rounded-xl h-96 animate-pulse"></div>
            ))}
         </div>
      ) : (
        <>
          {filteredProducts.length === 0 ? (
            <div className="text-center py-20 bg-gray-50 rounded-xl border-2 border-dashed border-gray-300">
               <div className="text-6xl mb-4">🏍️</div>
               <h3 className="text-2xl font-bold text-gray-900 mb-2">No encontramos productos</h3>
               <p className="text-gray-500 mb-6">Intenta con otra búsqueda o categoría.</p>
               {auth.isAuthenticated && (
                   <button 
                     onClick={() => setIsAddModalOpen(true)}
                     className="bg-blue-600 text-white px-6 py-2 rounded font-bold hover:bg-blue-700 transition"
                   >
                     Agregar Primer Producto
                   </button>
               )}
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </>
      )}
    </section>
  );
};

export default ShopSection;