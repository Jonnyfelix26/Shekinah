
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';

const Header: React.FC = () => {
  const { auth } = useAuth();
  const [logo, setLogo] = useState<string | null>(null);

  useEffect(() => {
    const savedLogo = localStorage.getItem('site_logo');
    if (savedLogo) {
      setLogo(savedLogo);
    }
  }, []);

  return (
    <header className="bg-gray-900 text-white py-6 px-6 border-b-4 border-blue-600 relative shadow-lg">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
          
          <div className="mb-4 md:mb-0 relative group flex items-center justify-center md:justify-start gap-5">
            {logo && (
              <img 
                src={logo} 
                alt="Logo" 
                className="h-16 md:h-24 object-contain bg-white p-1 rounded shadow-lg" 
              />
            )}

            <div className="flex flex-col items-center md:items-start">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-black italic tracking-tighter flex flex-col md:block text-center md:text-left leading-none drop-shadow-md">
                  <span className="text-blue-500">Shekinah</span>
                  <span className="text-white ml-2">Motor's</span>
                </h1>
                <p className="text-xs text-gray-400 tracking-[0.3em] uppercase mt-1">Repuestos y Accesorios</p>
            </div>
          </div>

          <div className="text-right flex flex-col items-center md:items-end gap-2 mt-4 md:mt-0">
            {/* Espacio para info extra si se requiere */}
          </div>
        </div>
      </header>
  );
};

export default Header;