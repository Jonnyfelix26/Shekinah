
import React, { useState, FormEvent } from 'react';
import { useAuth } from '../context/AuthContext';
import { LockIcon } from './Icons';

const LoginPage: React.FC<{ onCancel: () => void }> = ({ onCancel }) => {
  const { login } = useAuth();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleEmailLogin = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    try {
      await login(email, password);
    } catch (err: any) {
      console.error("Login Error:", err);
      if (err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password' || err.code === 'auth/user-not-found') {
         setError('Credenciales incorrectas.');
      } else if (err.code === 'auth/too-many-requests') {
         setError('Cuenta bloqueada temporalmente. Intenta más tarde.');
      } else if (err.code === 'auth/invalid-email') {
         setError('Formato de correo inválido.');
      } else {
         setError(`Error: ${err.message}`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#111827] relative overflow-hidden">
      
      {/* Background Effects */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
          <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] bg-blue-600/20 rounded-full blur-[100px]"></div>
          <div className="absolute top-[40%] -right-[10%] w-[40%] h-[40%] bg-blue-600/10 rounded-full blur-[100px]"></div>
      </div>

      <div className="bg-white/5 backdrop-blur-lg border border-white/10 w-full max-w-sm p-8 rounded-2xl shadow-2xl relative z-10 animate-fade-in-scale">
        <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg transform rotate-3">
                <LockIcon className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight">Shekinah <span className="text-blue-500">Admin</span></h2>
            <p className="text-gray-400 text-xs mt-1">Acceso Exclusivo Administrativo</p>
        </div>

        <form onSubmit={handleEmailLogin} className="space-y-5">
            <div>
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1 ml-1">Correo Electrónico</label>
                <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-gray-900/50 border border-gray-700 text-white px-4 py-3 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition placeholder-gray-600 text-sm"
                    placeholder="admin@shekinah.com"
                    required
                />
            </div>
            
            <div className="relative">
                <label className="block text-xs font-bold text-gray-500 uppercase mb-1 ml-1">Contraseña</label>
                <input 
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-gray-900/50 border border-gray-700 text-white px-4 py-3 rounded-lg focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition placeholder-gray-600 text-sm"
                    placeholder="••••••••"
                    required
                />
                <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-[28px] text-gray-500 hover:text-white text-[10px] uppercase font-bold"
                >
                    {showPassword ? 'Ocultar' : 'Ver'}
                </button>
            </div>

            {error && (
                <div className="bg-red-900/20 border border-red-900/50 p-3 rounded-lg">
                    <p className="text-red-400 text-xs text-center font-bold">{error}</p>
                </div>
            )}

            <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-3.5 rounded-xl shadow-lg transition-all transform active:scale-95 disabled:opacity-50 uppercase tracking-wider text-sm mt-2"
            >
                {loading ? 'Verificando...' : 'Iniciar Sesión'}
            </button>
        </form>

        <div className="mt-8 pt-6 border-t border-gray-700 text-center">
            <button onClick={onCancel} className="text-gray-500 hover:text-white text-xs transition flex items-center justify-center gap-1 mx-auto hover:underline">
                ← Regresar a la Tienda
            </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
